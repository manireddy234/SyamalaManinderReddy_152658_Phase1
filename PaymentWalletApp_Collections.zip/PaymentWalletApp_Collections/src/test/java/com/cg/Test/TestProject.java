package com.cg.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;

import com.cg.PaymentWalletApp.Exception.BankException;
import com.cg.PaymentWalletApp.bean.Customer;
import com.cg.PaymentWalletApp.bean.Wallet;
import com.cg.PaymentWalletApp.service.IWalletService;
import com.cg.PaymentWalletApp.service.WalletServiceImpl;

public class TestProject {
	public static IWalletService iWalletService=null;
	Customer customer1,customer2,customer3;
	
	@Before
	public void initData() {
		iWalletService=new WalletServiceImpl();
		customer1= new Customer("9505047640","Mani","Mani@0306","Mani123@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		customer2 = new Customer("9100501004","Neeraj","Neeraj@123","Neeraj123@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		customer3 = new Customer("9052263481","Pavan","Pavan@123","Pavan123@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
	}
	
	@Test(expected = BankException.class)
	public void checkMobileNumberError() throws BankException
	{
		iWalletService.checkMobileNumber("8888");
	}
	@Test
	public void checkMobileNumberTrue() throws BankException
	{
		iWalletService.checkMobileNumber("9100501004");
	}
	
	@Test(expected = BankException.class)
	public void checkNameTestError() throws BankException
	{
		iWalletService.checkName("");
	}
	
	@Test
	public void checkNameTest() throws BankException
	{
		iWalletService.checkName("Neeraj");
	}
	
	@Test(expected = BankException.class)
	public void passwordLengthError() throws BankException
	{
		iWalletService.checkPassword("Mani");
	}
	
	
	@Test(expected = BankException.class)
	public void passwordCapitalLetterError() throws BankException
	{
		iWalletService.checkPassword("mani@123");
	}
	@Test
	public void passwordTest() throws BankException
	{
		iWalletService.checkPassword("Mani@0306");
	}
	
	@Test(expected = BankException.class)
	public void emailTestFailDueToSymbol() throws BankException
	{
		iWalletService.checkEmail("Mani123gmail.com");
	}
	

	

	

	

	
	@Test
	public void addCustomerTestTrue() throws BankException
	{
		assertEquals("9505047640",iWalletService.addCustomer(customer1));
			
	}
	
	@Test
	public void checkForExistingCustomer() throws BankException
	{
		assertNotNull(iWalletService.check("9505047640", "Mani@0306"));
	}
    
	@Test(expected = BankException.class)
	public void checkForNonExistingCustomer() throws BankException
	{
		assertNull(iWalletService.check("9586234523", "John@1John"));
	}
	

    @Test
  	public void addCustomerTestFalse() throws BankException
  	{
  		assertNotEquals("6456564560",iWalletService.addCustomer(customer2));
  			
  	}
   
    
   
    
    @Test
    public void depositTestTrue()
    {
    	iWalletService.deposit(customer1, BigDecimal.valueOf(5000));
    }
    
    @Test
    public void withdrawTest() throws BankException
    {
    	iWalletService.deposit(customer2, BigDecimal.valueOf(5000));
    	assertEquals(true,iWalletService.withDraw(customer2, BigDecimal.valueOf(4000)));
    }
    
    @Test(expected = BankException.class)
    public void withdrawTestException() throws BankException
    {
    	iWalletService.addCustomer(customer3);
    	iWalletService.withDraw(customer3, BigDecimal.valueOf(5000));
  
    }
	@Test
	public void checkForReceiverExists() throws BankException
	{
		assertTrue(iWalletService.isFound("9505047640"));
	}
	
	@Test(expected = BankException.class)
	public void checkForReceiverNotExists() throws BankException
	{
		assertTrue(iWalletService.isFound("9494232097"));
	}
   
    
    @Test
    public void amountValidationTestForInteger() throws BankException {
    	assertTrue(iWalletService.checkEnteredAmount(BigDecimal.valueOf(5000)));
    }
    
    @Test
    public void amountValidationTestIfDigitsExistsAfterDecimalPoint() throws BankException {
    	assertTrue(iWalletService.checkEnteredAmount(BigDecimal.valueOf(5000.00)));
    }
    
    @Test
    public void amountValidationTestIfDigitsDoesntExistsAfterDecimalPoint() throws BankException {
    	assertTrue(iWalletService.checkEnteredAmount(BigDecimal.valueOf(5000.)));
    }
    
    
	
}
